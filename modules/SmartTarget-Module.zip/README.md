# SmartTarget module for STRI v1.0.1

## Installation

### Content Manager

- User Content Porter to import `cms\SmartTarget-Module - Import.xml` into the Content Manager

### Web Site

- Follow the SmartTarget 2014 SP1 documentation to deploy binaries & configuration to the Site project
- Deploy SmartTarget Area files to the Site project `Areas` folder
	- `web\Areas\SmartTarget\Views\web.config`
	- `web\Areas\SmartTarget\Views\Region\Inset1.cshtml`
	- `web\Areas\SmartTarget\Views\Region\Inset2.cshtml`
- Deploy SmartTarget module binaries to the Site project `bin` folder
	- `web\bin\Sdl.Web.Modules.SmartTarget.dll`
	- `web\bin\Sdl.Web.Modules.SmartTarget.DD4T.dll`
- Update the Site project unity configuration file (see `web\Unity.config` for example file)
	- Add assembly
		- `<assembly name="Sdl.Web.Modules.SmartTarget.DD4T" />`
	- Add namespaces
		- `<namespace name="Sdl.Web.Modules.SmartTarget.DD4T.Factories" />`
   	   	- `<namespace name="Sdl.Web.Modules.SmartTarget.DD4T.Html" />`
 	    - `<namespace name="Sdl.Web.Modules.SmartTarget.DD4T.Mapping" />`
 	- Update IModelBuilder implementation
 		- `<type type="IModelBuilder" mapTo="SmartTargetModelBuilder">`
 	- Update IRenderer implementation
 		- `<type type="IRenderer" mapTo="SmartTargetRenderer">`
 	- Add IComponentPresentationFactory implementation
 		- `<type type="IComponentPresentationFactory" mapTo="ComponentPresentationFactory" />`
 
