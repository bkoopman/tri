Release Notes for Search module for STRI 1.0.1

Version:
This module is intended for the SDL Tridion Reference Implementation 1.0.1

Installation:
To install the Module, run the import script from the Search module installation media (modules\Search\ folder), then perform a number of configuration and publish actions.
To install the Search Module in your Web application, run a PowerShell script from the Search module installation media (modules\Search\ folder) to install it, then edit its Unity configuration file to specify namespaces and assembles, and to set a type.
Further details can be found in the documentation.
