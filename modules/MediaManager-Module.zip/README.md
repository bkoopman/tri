# Media Manager module for STRI v1.0.1

## Installation

### Content Manager

- User Content Porter to import `cms\MediaManager-Module - Import.xml` into the Content Manager
- Add the `Resolve Media Manager References` TBB to Media Manager enabled Component Templates
	- Alternatively add it to the `Default Component Template Finish Actions` TBB

### Web Site

- Update the entity view to render out the Media Manager distribution

Code example:

	@if (Model.Media.MimeType == "application/externalcontentlibrary")
	{
		<iframe frameborder="0" scrolling="no" src="@Model.Media.Url"> </iframe>
	} 
