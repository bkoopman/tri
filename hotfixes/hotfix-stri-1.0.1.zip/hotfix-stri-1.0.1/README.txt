Release Notes for Hotfix 1.0.1

Version:
This hotfix is intended for SDL Tridion Reference Implementation 1.0

Problem description:
This hotfix is a cumulative fix for the following issues:
1. Modules do not have separate HTML Design configuration
2. Example Site Homepage Carousel elements do not have links
3. Need to manually install System.Web.Helpers in CM server GAC (typically by installing MVC4+)
4. Cannot work with article paragraph blocks in Experience Manager
5. Larger images are not served to 'retina' display devices
6. No helpful errors when invalid publication id in cd_dynamic_conf.xml
7. Language selector always takes you to default content, even if the current page is available in another language
8. Language selector default gives object moved error for default language
9. Editing carousel content in Experience Manager shows <Add text> and you cannot edit the text directly
10. IE9,10: Label on Carousel should be semitransparent
11. Drop down list of language selector is white when Language selector is added to footer page

Hotfix description:
The hotfix contains a CM part and a web application part, which contain code and content changes to address the issues.

Installation:
	1. Run the \import\import.ps1 Powershell script to update your CMS (either edit it to set an appropriate CMS url, or pass this as a parameter)
	2. Republish the /Home/000 Home and /Home/_System/Publish HTML Design pages from the CMS
	3. Copy the contents of the web folder into your web application root folder
    4. Recycle the application pool or restart your IIS service

Disclaimer:
Hotfixes are released at the discretion of SDL based on technical complexity, customer business requirements and schedules. Hotfixes are made and tested only for the described problem on a particular environment/configuration and therefore should only be installed if approved by Customer Support of SDL Web Content Management Solutions Division. Hotfixes should be replaced as soon as possible by the subsequent service pack where the problem is fixed.
Copyright � 2014 SDL PLC. All Rights Reserved. All company product or service names referenced herein are properties of their respective owners. 
